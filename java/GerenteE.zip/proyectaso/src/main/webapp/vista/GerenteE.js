// Variables globales (Mantén solo las necesarias para GerenteE.jsp)
let historial = ['vista-perfil'];
let accionActual = null;
let datosAccion = {};

// Base de datos de entregas (ejemplo) - Mantén esta si la usas en GerenteE.jsp
let entregasDB = {
    "001": {
        persona: "Juan López",
        direccion: "Calle A 123",
        productos: "5",
        contacto: "+123456789",
        estado: "activa"
    },
    "002": {
        persona: "Maria García",
        direccion: "Avenida B 456",
        productos: "3",
        contacto: "+987654321",
        estado: "activa"
    },
    "003": {
        persona: "Carlos Martínez",
        direccion: "Boulevard C 789",
        productos: "2",
        contacto: "+456123789",
        estado: "activa"
    }
};

// Inicialización: Se ejecuta cuando el DOM está completamente cargado
document.addEventListener('DOMContentLoaded', function() {
    actualizarVistas(); // Muestra la vista inicial (perfil)
    cargarEntregasEnSelectores(); // Carga las entregas en los selectores de asignación/cancelación
    renderizarTablaEntregas(); // Renderiza la tabla de entregas
});

// --- Funciones de Navegación ---
function navegar(vista) {
    // Si ya estamos en esa vista, no hacemos nada
    if (historial[historial.length - 1] === vista) {
        return;
    }
    historial.push(vista); // Añade la nueva vista al historial
    actualizarVistas(); // Actualiza la interfaz para mostrar la vista actual
}

function retroceder() {
    if (historial.length > 1) { // Asegura que no eliminemos la vista inicial
        historial.pop(); // Elimina la vista actual del historial
        actualizarVistas(); // Actualiza la interfaz para mostrar la vista anterior
    }
}

function actualizarVistas() {
    // Oculta todas las secciones <main>
    document.querySelectorAll('main').forEach(main => main.classList.add('hidden'));
    
    // Muestra la sección <main> actual
    const vistaActual = historial[historial.length - 1];
    const currentViewElement = document.getElementById(vistaActual);
    if (currentViewElement) {
        currentViewElement.classList.remove('hidden');
    }
    
    // Muestra u oculta la flecha de retroceso (solo si hay historial de navegación interno)
    // Para la navegación a listar.jsp, la flecha se maneja en listar.jsp
    document.getElementById('back-arrow').classList.toggle('active', historial.length > 1);
    
    // Oculta los resultados de acciones (asignación, cancelación) y la entrega específica al cambiar de vista
    document.getElementById('resultado-asignacion').classList.add('hidden');
    document.getElementById('resultado-cancelacion').classList.add('hidden');
    document.getElementById('entrega-especifica').classList.add('hidden');

    // Lógica específica para cada vista al activarse
    if (vistaActual === 'vista-consultar') {
        document.getElementById('tabla-entregas').classList.remove('hidden'); // Asegura que la tabla esté visible
        renderizarTablaEntregas(); // Re-renderiza para mostrar datos actualizados
        cargarEntregasEnSelectores(); // Recarga las entregas para asignar/cancelar
    } else if (vistaActual === 'vista-distribuidor' || vistaActual === 'vista-cancelar') {
        cargarEntregasEnSelectores(); // Recarga las entregas para asignación/cancelación
        // No necesitas actualizar selectores de distribuidores si no los manejas en este JS
        // Si necesitas cargar distribuidores para asignar, los cargarías desde tu backend en este punto.
    } else {
        // En otras vistas, como el perfil, oculta la tabla si estaba visible
        document.getElementById('tabla-entregas').classList.add('hidden');
    }
}

// --- Funciones de Entregas ---
function buscarEntregas() {
    // Esta función actualmente solo renderiza la tabla.
    // Aquí iría la lógica para filtrar las entregas basadas en el selector 'filtro-entregas'.
    document.getElementById('tabla-entregas').classList.remove('hidden');
    renderizarTablaEntregas();
}

function buscarEntregaEspecifica() {
    const numeroEntrega = document.getElementById('numero-entrega').value.trim();
    const entregaEspecificaDiv = document.getElementById('entrega-especifica');
    
    if (numeroEntrega) {
        if (entregasDB[numeroEntrega] && entregasDB[numeroEntrega].estado === "activa") {
            const entrega = entregasDB[numeroEntrega];
            document.getElementById('entrega-numero').textContent = numeroEntrega;
            document.getElementById('entrega-persona').textContent = entrega.persona;
            document.getElementById('entrega-direccion').textContent = entrega.direccion;
            document.getElementById('entrega-productos').textContent = entrega.productos;
            document.getElementById('entrega-contacto').textContent = entrega.contacto;
            
            entregaEspecificaDiv.classList.remove('hidden');
            document.getElementById('tabla-entregas').classList.add('hidden'); // Oculta la tabla general
        } else {
            alert(`No se encontró la entrega #${numeroEntrega} o ha sido cancelada.`);
            entregaEspecificaDiv.classList.add('hidden');
            document.getElementById('tabla-entregas').classList.remove('hidden'); // Muestra la tabla general si no se encuentra
        }
    } else {
        alert("Por favor ingrese un número de entrega.");
        entregaEspecificaDiv.classList.add('hidden');
        document.getElementById('tabla-entregas').classList.remove('hidden'); // Muestra la tabla general si el campo está vacío
    }
}

function cargarEntregasEnSelectores() {
    const selectAsignacion = document.getElementById('entrega-distribuidor');
    const selectCancelacion = document.getElementById('entrega-cancelar');
    
    // Limpiar selectores, manteniendo la primera opción
    [selectAsignacion, selectCancelacion].forEach(select => {
        while (select.options.length > 1) {
            select.remove(1);
        }
    });
    
    // Llenar selectores con entregas activas
    Object.keys(entregasDB).forEach(key => {
        if (entregasDB[key].estado === "activa") {
            const entrega = entregasDB[key];
            const optionText = `${key} - ${entrega.persona}`;
            
            const optionAsignacion = document.createElement('option');
            optionAsignacion.value = key;
            optionAsignacion.textContent = optionText;
            selectAsignacion.appendChild(optionAsignacion);
            
            const optionCancelacion = document.createElement('option');
            optionCancelacion.value = key;
            optionCancelacion.textContent = optionText;
            selectCancelacion.appendChild(optionCancelacion);
        }
    });
}

function renderizarTablaEntregas() {
    const tbody = document.getElementById('entregas-body');
    tbody.innerHTML = ''; // Limpia la tabla antes de renderizar
    
    // Llenar tabla solo con entregas activas
    Object.keys(entregasDB).forEach(key => {
        if (entregasDB[key].estado === "activa") {
            const entrega = entregasDB[key];
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${key}</td>
                <td>${entrega.persona}</td>
                <td>${entrega.direccion}</td>
                <td>${entrega.productos}</td>
                <td>${entrega.contacto}</td>
            `;
            tbody.appendChild(row);
        }
    });
}

// --- Funciones de Modal de Confirmación (Se mantienen ya que son genéricas) ---
const confirmationModal = document.getElementById('confirmation-modal');
const modalTitle = document.getElementById('modal-title');
const modalMessage = document.getElementById('modal-message');

function mostrarModal(title, message, actionCallback) {
    modalTitle.textContent = title;
    modalMessage.textContent = message;
    accionActual = actionCallback;
    confirmationModal.classList.add('active');
}

function cerrarModal() {
    confirmationModal.classList.remove('active');
    accionActual = null;
    datosAccion = {}; // Limpia los datos de la acción
}

function confirmarAccion() {
    if (accionActual) {
        accionActual();
    }
    cerrarModal();
}

// --- Funciones de Asignación y Cancelación (Mantener) ---
function mostrarConfirmacionDistribuidor() {
    const entregaId = document.getElementById('entrega-distribuidor').value;
    const distribuidorId = document.getElementById('distribuidor-elegido').value;
    
    if (!entregaId || !distribuidorId) {
        alert('Por favor, seleccione una entrega y un distribuidor.');
        return;
    }

    // Aquí deberías obtener el nombre real del distribuidor y la entrega si la tienes en tu JS
    // Para este ejemplo, usaremos los IDs directamente.
    const entregaInfo = entregasDB[entregaId] ? `Entrega #${entregaId} (${entregasDB[entregaId].persona})` : `Entrega #${entregaId}`;
    const distribuidorInfo = distribuidorId; // O buscar el nombre si tuvieras la lista de distribuidores aquí.

    datosAccion = { entregaId, distribuidorId };
    mostrarModal(
        'Confirmar Asignación',
        `¿Está seguro de asignar el distribuidor "${distribuidorInfo}" a la ${entregaInfo}?`,
        asignarDistribuidor
    );
}

function asignarDistribuidor() {
    const { entregaId, distribuidorId } = datosAccion;
    // Lógica para asignar distribuidor a la entrega (simulado)
    console.log(`Asignando distribuidor ${distribuidorId} a la entrega ${entregaId}`);

    // Simula éxito y muestra el resultado
    document.getElementById('result-entrega-dist').textContent = entregaId;
    document.getElementById('result-distribuidor').textContent = distribuidorId; // Mejorar con nombre si está disponible
    document.getElementById('result-fecha-dist').textContent = new Date().toLocaleDateString();
    
    document.getElementById('resultado-asignacion').classList.remove('hidden');
    // Reiniciar selectores
    document.getElementById('entrega-distribuidor').selectedIndex = 0;
    document.getElementById('distribuidor-elegido').selectedIndex = 0;
    
    // En un caso real, harías una llamada AJAX a tu backend aquí
}

function mostrarConfirmacionCancelacion() {
    const entregaId = document.getElementById('entrega-cancelar').value;
    const razon = document.getElementById('razon-cancelacion').value;
    
    if (!entregaId || !razon) {
        alert('Por favor, seleccione una entrega y una razón de cancelación.');
        return;
    }

    const entregaInfo = entregasDB[entregaId] ? `Entrega #${entregaId} (${entregasDB[entregaId].persona})` : `Entrega #${entregaId}`;
    
    datosAccion = { entregaId, razon };
    mostrarModal(
        'Confirmar Cancelación',
        `¿Está seguro de cancelar la ${entregaInfo} por la razón: "${razon}"?`,
        cancelarEntrega
    );
}

function cancelarEntrega() {
    const { entregaId, razon } = datosAccion;
    // Lógica para cancelar la entrega (simulado)
    if (entregasDB[entregaId]) {
        entregasDB[entregaId].estado = "cancelada"; // Cambiar estado
        console.log(`Entrega ${entregaId} cancelada por: ${razon}`);

        // Simula éxito y muestra el resultado
        document.getElementById('result-entrega-cancel').textContent = entregaId;
        document.getElementById('result-razon').textContent = razon;
        document.getElementById('result-fecha-cancel').textContent = new Date().toLocaleDateString();
        
        document.getElementById('resultado-cancelacion').classList.remove('hidden');
        
        // Actualizar la tabla de entregas y los selectores
        renderizarTablaEntregas();
        cargarEntregasEnSelectores();
        
        // Reiniciar selectores
        document.getElementById('entrega-cancelar').selectedIndex = 0;
        document.getElementById('razon-cancelacion').selectedIndex = 0;

        // En un caso real, harías una llamada AJAX a tu backend aquí
    } else {
        alert(`Error: La entrega #${entregaId} no se pudo cancelar.`);
    }
}

function cerrarSesion() {
    // Aquí puedes añadir lógica para limpiar la sesión en el cliente
    // Por ejemplo, localStorage.clear() o sessionStorage.clear()
    // La redirección a index.html ya se maneja con el <a> tag
    console.log("Sesión cerrada.");
}

// Nota: Las funciones relacionadas con la gestión de distribuidores (agregar, editar, eliminar,
// renderizarListaDistribuidores, etc.) deben eliminarse de este archivo JS,
// ya que listar.jsp ahora es una página separada con su propia lógica de backend.
// Si listar.jsp necesita JS para su CRUD, debería tener su propio archivo JS.

// Ejemplo de cómo podrías obtener distribuidores para el selector de asignación desde el backend
// Esto requeriría un endpoint para obtener los distribuidores.
function actualizarSelectoresDistribuidores() {
    const selectDistribuidor = document.getElementById('distribuidor-elegido');
    // Limpiar selector, manteniendo la primera opción
    while (selectDistribuidor.options.length > 1) {
        selectDistribuidor.remove(1);
    }

    // Simulamos una llamada a un backend para obtener los distribuidores
    // En un caso real, harías un fetch() a tu API:
    // fetch('/api/distribuidores')
    //     .then(response => response.json())
    //     .then(data => {
    //         data.forEach(dist => {
    //             const option = document.createElement('option');
    //             option.value = dist.id; // Asume que cada distribuidor tiene un 'id'
    //             option.textContent = dist.nombre; // Asume que tiene un 'nombre'
    //             selectDistribuidor.appendChild(option);
    //         });
    //     })
    //     .catch(error => console.error('Error al cargar distribuidores:', error));
    
    // Para propósitos de este ejemplo, usaremos los distribuidores del JS anterior si no los borraste
    // O podrías tener un array global simulado aquí, pero lo ideal es que vengan del backend
    const distribuidoresSimulados = [
        { id: 'DIST001', nombre: 'Juan Repartidor' },
        { id: 'DIST002', nombre: 'María Veloz' },
        { id: 'DIST003', nombre: 'Pedro Cumplido' }
    ];

    distribuidoresSimulados.forEach(dist => {
        const option = document.createElement('option');
        option.value = dist.id;
        option.textContent = dist.nombre;
        selectDistribuidor.appendChild(option);
    });
}