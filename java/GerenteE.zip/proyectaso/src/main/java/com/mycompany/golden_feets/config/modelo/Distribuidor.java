package com.mycompany.golden_feets.config.modelo;

public class Distribuidor {
    private int idDistribuidor;
    private String nombre;
    private String direccion;
    private String telefono;

    public Distribuidor() {}

    public Distribuidor(int idDistribuidor, String nombre, String direccion, String telefono) {
        this.idDistribuidor = idDistribuidor;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    public int getIdDistribuidor() {
        return idDistribuidor;
    }

    public void setIdDistribuidor(int idDistribuidor) {
        this.idDistribuidor = idDistribuidor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public boolean isValid() {
        return nombre != null && nombre.matches("[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,60}") &&
               direccion != null && direccion.length() >= 5 && direccion.length() <= 120 &&
               telefono != null && telefono.matches("\\d{7,10}");
    }

    public void trimAllFields() {
        if (nombre != null) nombre = nombre.trim();
        if (direccion != null) direccion = direccion.trim();
        if (telefono != null) telefono = telefono.trim();
    }

    @Override
    public String toString() {
        return "Distribuidor{" +
                "idDistribuidor=" + idDistribuidor +
                ", nombre='" + nombre + '\'' +
                ", direccion='" + direccion + '\'' +
                ", telefono='" + telefono + '\'' +
                '}';
    }
}
