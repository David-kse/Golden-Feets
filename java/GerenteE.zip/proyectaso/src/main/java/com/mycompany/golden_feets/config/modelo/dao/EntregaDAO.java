package com.mycompany.golden_feets.config.modelo.dao;

import com.mycompany.golden_feets.config.conexion.Conexion;
import com.mycompany.golden_feets.config.modelo.Entrega;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EntregaDAO {
    private static final String SQL_SELECT_ALL = "SELECT id_entrega, id_venta, fecha_entrega, estado FROM entrega";
    private static final String SQL_SELECT_BY_ID = "SELECT id_entrega, id_venta, fecha_entrega, estado FROM entrega WHERE id_entrega = ?";
    private static final String SQL_INSERT = "INSERT INTO entrega(id_venta, fecha_entrega, estado) VALUES(?, ?, ?)";
    private static final String SQL_UPDATE = "UPDATE entrega SET id_venta = ?, fecha_entrega = ?, estado = ? WHERE id_entrega = ?";
    private static final String SQL_DELETE = "DELETE FROM entrega WHERE id_entrega = ?";
    private static final String SQL_UPDATE_ESTADO = "UPDATE entrega SET estado = ? WHERE id_entrega = ?";

    public List<Entrega> listarTodas() {
        List<Entrega> entregas = new ArrayList<>();
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_ALL);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                entregas.add(mapearEntrega(rs));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return entregas;
    }

    public Entrega buscarPorId(int id) {
        Entrega entrega = null;
        
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_ID)) {
            
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    entrega = mapearEntrega(rs);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return entrega;
    }

    public boolean crear(Entrega entrega) {
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, entrega.getIdVenta());
            
            if (entrega.getFechaEntrega() != null) {
                stmt.setDate(2, Date.valueOf(entrega.getFechaEntrega()));
            } else {
                stmt.setNull(2, Types.DATE);
            }
            
            stmt.setString(3, entrega.getEstado());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        entrega.setIdEntrega(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public boolean actualizar(Entrega entrega) {
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_UPDATE)) {
            
            stmt.setInt(1, entrega.getIdVenta());
            
            if (entrega.getFechaEntrega() != null) {
                stmt.setDate(2, Date.valueOf(entrega.getFechaEntrega()));
            } else {
                stmt.setNull(2, Types.DATE);
            }
            
            stmt.setString(3, entrega.getEstado());
            stmt.setInt(4, entrega.getIdEntrega());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public boolean eliminar(int id) {
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_DELETE)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public boolean actualizarEstado(int idEntrega, String nuevoEstado) {
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_UPDATE_ESTADO)) {
            
            stmt.setString(1, nuevoEstado);
            stmt.setInt(2, idEntrega);
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    private Entrega mapearEntrega(ResultSet rs) throws SQLException {
        Entrega entrega = new Entrega();
        entrega.setIdEntrega(rs.getInt("id_entrega"));
        entrega.setIdVenta(rs.getInt("id_venta"));
        
        Date fecha = rs.getDate("fecha_entrega");
        if (fecha != null) {
            entrega.setFechaEntrega(fecha.toLocalDate());
        }
        
        entrega.setEstado(rs.getString("estado"));
        return entrega;
    }
}