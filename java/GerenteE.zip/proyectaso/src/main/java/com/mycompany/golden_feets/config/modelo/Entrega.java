package com.mycompany.golden_feets.config.modelo;

import java.time.LocalDate;

public class Entrega {
    private int idEntrega;
    private int idVenta;
    private LocalDate fechaEntrega;
    private String estado;

    // Estados constantes
    public static final String PENDIENTE = "Pendiente";
    public static final String EN_TRANSITO = "En transito";
    public static final String ENTREGADO = "Entregado";
    public static final String CANCELADO = "Cancelado";

    public Entrega() {
        this.estado = PENDIENTE;
    }

    public Entrega(int idEntrega, int idVenta, LocalDate fechaEntrega, String estado) {
        this.idEntrega = idEntrega;
        this.idVenta = idVenta;
        this.fechaEntrega = fechaEntrega;
        this.estado = (estado != null) ? estado : PENDIENTE;
    }

    // Getters y Setters
    public int getIdEntrega() {
        return idEntrega;
    }

    public void setIdEntrega(int idEntrega) {
        this.idEntrega = idEntrega;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public LocalDate getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(LocalDate fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = (estado != null) ? estado : PENDIENTE;
    }
}