package com.mycompany.golden_feets.config.controlador;

import com.mycompany.golden_feets.config.modelo.Entrega;
import com.mycompany.golden_feets.config.modelo.dao.EntregaDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

@WebServlet(name = "EntregaControlador", urlPatterns = {"/EntregaControlador"})
public class EntregaControlador extends HttpServlet {

    private final EntregaDAO entregaDAO = new EntregaDAO();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion = request.getParameter("accion");
        
        if (accion == null || accion.isEmpty()) {
            accion = "listar";
        }

        try {
            switch (accion) {
                case "listar":
                    listarEntregas(request, response);
                    break;
                case "nuevo":
                    mostrarFormularioNuevo(request, response);
                    break;
                case "crear":
                    crearEntrega(request, response);
                    break;
                case "editar":
                    mostrarFormularioEdicion(request, response);
                    break;
                case "actualizar":
                    actualizarEntrega(request, response);
                    break;
                case "eliminar":
                    eliminarEntrega(request, response);
                    break;
                case "cancelar":
                    cancelarEntrega(request, response);
                    break;
                case "detalle":
                    mostrarDetalle(request, response);
                    break;
                default:
                    listarEntregas(request, response);
            }
        } catch (Exception e) {
            request.setAttribute("error", "Error: " + e.getMessage());
            listarEntregas(request, response);
        }
    }

    private void listarEntregas(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Entrega> entregas = entregaDAO.listarTodas();
        request.setAttribute("entregas", entregas);
        request.getRequestDispatcher("/vista/GerenteE.jsp").forward(request, response);
    }

    private void mostrarFormularioNuevo(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/vista/nuevaEntrega.jsp").forward(request, response);
    }

    private void crearEntrega(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int idVenta = Integer.parseInt(request.getParameter("idVenta"));
            String fechaStr = request.getParameter("fechaEntrega");
            String estado = request.getParameter("estado");
            
            LocalDate fechaEntrega = null;
            if (fechaStr != null && !fechaStr.isEmpty()) {
                fechaEntrega = LocalDate.parse(fechaStr);
            }
            
            Entrega nuevaEntrega = new Entrega(0, idVenta, fechaEntrega, estado);
            
            if (entregaDAO.crear(nuevaEntrega)) {
                request.setAttribute("mensajeExito", "Entrega creada exitosamente");
            } else {
                request.setAttribute("mensajeError", "Error al crear la entrega");
            }
        } catch (Exception e) {
            request.setAttribute("mensajeError", "Error en los datos: " + e.getMessage());
        }
        
        listarEntregas(request, response);
    }

    private void mostrarFormularioEdicion(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            Entrega entrega = entregaDAO.buscarPorId(id);
            
            if (entrega != null) {
                request.setAttribute("entrega", entrega);
                request.getRequestDispatcher("/vista/editarEntrega.jsp").forward(request, response);
            } else {
                request.setAttribute("mensajeError", "No se encontró la entrega con ID: " + id);
                listarEntregas(request, response);
            }
        } catch (NumberFormatException e) {
            request.setAttribute("mensajeError", "ID de entrega inválido");
            listarEntregas(request, response);
        }
    }

    private void actualizarEntrega(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int idEntrega = Integer.parseInt(request.getParameter("idEntrega"));
            int idVenta = Integer.parseInt(request.getParameter("idVenta"));
            String fechaStr = request.getParameter("fechaEntrega");
            String estado = request.getParameter("estado");
            
            LocalDate fechaEntrega = null;
            if (fechaStr != null && !fechaStr.isEmpty()) {
                fechaEntrega = LocalDate.parse(fechaStr);
            }
            
            Entrega entrega = new Entrega(idEntrega, idVenta, fechaEntrega, estado);
            
            if (entregaDAO.actualizar(entrega)) {
                request.setAttribute("mensajeExito", "Entrega actualizada correctamente");
            } else {
                request.setAttribute("mensajeError", "Error al actualizar la entrega");
            }
        } catch (Exception e) {
            request.setAttribute("mensajeError", "Error en los datos: " + e.getMessage());
        }
        
        listarEntregas(request, response);
    }

    private void eliminarEntrega(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            
            if (entregaDAO.eliminar(id)) {
                request.setAttribute("mensajeExito", "Entrega eliminada correctamente");
            } else {
                request.setAttribute("mensajeError", "Error al eliminar la entrega");
            }
        } catch (NumberFormatException e) {
            request.setAttribute("mensajeError", "ID de entrega inválido");
        }
        
        listarEntregas(request, response);
    }

    private void cancelarEntrega(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            
            if (entregaDAO.actualizarEstado(id, Entrega.CANCELADO)) {
                request.setAttribute("mensajeExito", "Entrega cancelada exitosamente");
            } else {
                request.setAttribute("mensajeError", "No se pudo cancelar la entrega");
            }
        } catch (NumberFormatException e) {
            request.setAttribute("mensajeError", "ID de entrega inválido");
        }
        
        listarEntregas(request, response);
    }

    private void mostrarDetalle(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            Entrega entrega = entregaDAO.buscarPorId(id);
            
            if (entrega != null) {
                request.setAttribute("entrega", entrega);
                request.getRequestDispatcher("/vista/detalleEntrega.jsp").forward(request, response);
            } else {
                request.setAttribute("mensajeError", "No se encontró la entrega con ID: " + id);
                listarEntregas(request, response);
            }
        } catch (NumberFormatException e) {
            request.setAttribute("mensajeError", "ID de entrega inválido");
            listarEntregas(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}