package com.mycompany.golden_feets.config.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Clase de utilidad para gestionar la conexión a la base de datos MySQL.
 * Utiliza un patrón Singleton simplificado para la instancia de conexión,
 * rehusando la conexión si ya está abierta y es válida.
 * Proporciona métodos estáticos para obtener y cerrar la conexión.
 */
public class Conexion {

    // --- Constantes de Configuración de la Base de Datos ---
    private static final String USERNAME = "root"; // Tu nombre de usuario de la base de datos MySQL
    private static final String PASSWORD = "";     // Tu contraseña de la base de datos MySQL (vacía si no tienes)
    private static final String DATABASE = "golden_feets"; // Nombre de tu base de datos
    
    // URL de conexión a la base de datos MySQL.
    // Incluye parámetros para evitar advertencias comunes con el conector MySQL/J.
    // - useSSL=false: Desactiva el uso de SSL (puede ser true si tu servidor MySQL usa SSL)
    // - serverTimezone=UTC: Establece la zona horaria del servidor (importante para fechas/horas)
    // - allowPublicKeyRetrieval=true: Necesario si tu servidor MySQL usa autenticación caching_sha2_password
    private static final String URL = "jdbc:mysql://localhost:3306/" + DATABASE + 
                                      "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    
    // --- Variable estática para almacenar la única instancia de la conexión ---
    private static Connection connection = null;

    // --- Constructor Privado ---
    /**
     * Constructor privado para evitar la instanciación directa de esta clase.
     * Esto refuerza que es una clase de utilidad con métodos estáticos.
     */
    private Conexion() {
        // No se permite la instanciación externa.
    }

    // --- Métodos Públicos Estáticos para la Gestión de Conexiones ---

    /**
     * Obtiene una instancia de la conexión a la base de datos.
     * Si la conexión no existe o está cerrada o es inválida, intenta establecer una nueva.
     * En un entorno de aplicación web con múltiples hilos, esta implementación básica
     * puede ser insuficiente para un alto rendimiento o manejo de transacciones complejas.
     * Para ello, se recomendaría un pool de conexiones (ej. HikariCP, Apache DBCP).
     *
     * @return Una conexión activa a la base de datos, o {@code null} si falla el establecimiento de la conexión.
     */
    public static Connection getConnection() {
        try {
            // Verifica si la conexión actual es nula, está cerrada, o no es válida.
            // connection.isValid(2) comprueba si la conexión está viva con un timeout de 2 segundos.
            if (connection == null || connection.isClosed() || !connection.isValid(2)) {
                // Cargar el driver de MySQL.
                // En JDBC 4.0 (Java 6) y posteriores, el driver se autocarga si está en el classpath,
                // por lo que Class.forName() no es estrictamente necesario, pero no hace daño y puede ayudar
                // en ciertos escenarios o versiones de entorno.
                Class.forName("com.mysql.cj.jdbc.Driver");
                
                // Establecer la nueva conexión a la base de datos.
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                
                // Confirmación visual de la conexión
                if (connection != null && !connection.isClosed()) {
                    System.out.println("✅ Conexión establecida exitosamente a la base de datos: " + DATABASE);
                }
            } else {
                System.out.println("✅ Conexión existente reutilizada."); // Mensaje para saber que se rehusó la conexión
            }
            
        } catch (SQLException e) {
            // Manejo de errores específicos de SQL
            System.err.println("❌ Error de conexión a la base de datos:");
            System.err.println("  URL: " + URL);
            System.err.println("  Usuario: " + USERNAME);
            System.err.println("  Mensaje: " + e.getMessage());
            e.printStackTrace(); // Imprime la pila de llamadas para depuración detallada
            connection = null; // Asegurarse de que la conexión sea nula en caso de error
        } catch (ClassNotFoundException e) {
            // Manejo de error si el driver JDBC no se encuentra
            System.err.println("❌ Error: Driver MySQL no encontrado.");
            System.err.println("  Asegúrate de que el JAR del conector MySQL (ej. mysql-connector-j-x.x.x.jar) esté en las librerías de tu proyecto.");
            e.printStackTrace();
            connection = null;
        }
        
        return connection; // Retorna la conexión (puede ser null si hubo un error)
    }
    
    /**
     * Cierra la conexión a la base de datos si está abierta y no es nula.
     * Este método debería ser llamado para liberar recursos cuando la aplicación
     * se apaga o ya no necesita la conexión global.
     */
    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("🔒 Conexión cerrada exitosamente");
                connection = null; // Restablecer a null después de cerrar para permitir una nueva conexión si se necesita
            }
        } catch (SQLException e) {
            System.err.println("❌ Error al cerrar la conexión:");
            e.printStackTrace();
        }
    }
    
    /**
     * Prueba la conexión a la base de datos de forma independiente.
     * Este método es útil para verificar la configuración de la base de datos
     * y las credenciales sin afectar la conexión principal gestionada por {@code getConnection()}.
     * Siempre cierra la conexión de prueba que abre.
     *
     * @return {@code true} si se puede establecer y validar una conexión, {@code false} en caso contrario.
     */
    public static boolean testConnection() {
        Connection testConn = null; // Conexión local para la prueba
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            testConn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            boolean isValid = testConn.isValid(5); // Prueba de validez con un timeout de 5 segundos
            System.out.println("DEBUG: Conexión de prueba a '" + DATABASE + "' es válida: " + isValid);
            return isValid;
        } catch (ClassNotFoundException e) {
            System.err.println("❌ Error en testConnection: Driver MySQL no encontrado.");
            System.err.println("  Detalle: " + e.getMessage());
            e.printStackTrace();
            return false;
        } catch (SQLException e) {
            System.err.println("❌ Error en testConnection: Fallo al conectar a la base de datos.");
            System.err.println("  Mensaje: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            // Asegurarse de cerrar la conexión de prueba en cualquier caso
            if (testConn != null) {
                try {
                    testConn.close(); 
                    System.out.println("DEBUG: Conexión de prueba cerrada.");
                } catch (SQLException e) {
                    System.err.println("❌ Error al cerrar la conexión de prueba: " + e.getMessage());
                }
            }
        }
    }
}