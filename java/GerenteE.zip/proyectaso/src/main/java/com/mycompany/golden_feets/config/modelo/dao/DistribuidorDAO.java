package com.mycompany.golden_feets.config.modelo.dao;

import com.mycompany.golden_feets.config.conexion.Conexion;
import com.mycompany.golden_feets.config.modelo.Distribuidor;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DistribuidorDAO {

    private static final Logger LOGGER = Logger.getLogger(DistribuidorDAO.class.getName());

    private static final String SQL_SELECT_ALL = 
        "SELECT id_distribuidor, nombre, direccion, telefono FROM distribuidor ORDER BY id_distribuidor";
    private static final String SQL_SELECT_BY_ID = 
        "SELECT id_distribuidor, nombre, direccion, telefono FROM distribuidor WHERE id_distribuidor = ?";
    private static final String SQL_INSERT = 
        "INSERT INTO distribuidor (nombre, direccion, telefono) VALUES (?, ?, ?)";
    private static final String SQL_UPDATE = 
        "UPDATE distribuidor SET nombre = ?, direccion = ?, telefono = ? WHERE id_distribuidor = ?";
    private static final String SQL_DELETE = 
        "DELETE FROM distribuidor WHERE id_distribuidor = ?";

    public List<Distribuidor> listarDistribuidores() {
        List<Distribuidor> distribuidores = new ArrayList<>();
        try (Connection conn = Conexion.getConnection()) {
            if (conn == null) {
                LOGGER.severe("❌ No se pudo establecer conexión a la base de datos");
                return distribuidores;
            }
            try (PreparedStatement pstmt = conn.prepareStatement(SQL_SELECT_ALL);
                 ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Distribuidor distribuidor = mapearResultSet(rs);
                    if (distribuidor != null) {
                        distribuidores.add(distribuidor);
                    }
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "❌ Error al consultar distribuidores", e);
        }
        return distribuidores;
    }

    public Distribuidor buscarPorId(int id) {
        if (id <= 0) {
            LOGGER.warning("⚠️ ID inválido para búsqueda: " + id);
            return null;
        }
        Distribuidor distribuidor = null;
        try (Connection conn = Conexion.getConnection()) {
            if (conn == null) {
                LOGGER.severe("❌ No se pudo establecer conexión a la base de datos");
                return null;
            }
            try (PreparedStatement pstmt = conn.prepareStatement(SQL_SELECT_BY_ID)) {
                pstmt.setInt(1, id);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        distribuidor = mapearResultSet(rs);
                    }
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "❌ Error al buscar distribuidor por ID: " + id, e);
        }
        return distribuidor;
    }

    public boolean insertarDistribuidor(Distribuidor distribuidor) {
        if (distribuidor == null) {
            LOGGER.warning("⚠️ Distribuidor inválido para insertar");
            return false;
        }
        try (Connection conn = Conexion.getConnection()) {
            if (conn == null) {
                LOGGER.severe("❌ No se pudo establecer conexión a la base de datos");
                return false;
            }
            distribuidor.trimAllFields();
            try (PreparedStatement pstmt = conn.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setString(1, distribuidor.getNombre());
                pstmt.setString(2, distribuidor.getDireccion());
                pstmt.setString(3, distribuidor.getTelefono());

                int filasAfectadas = pstmt.executeUpdate();
                if (filasAfectadas > 0) {
                    try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            distribuidor.setIdDistribuidor(generatedKeys.getInt(1));
                        }
                    }
                    return true;
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "❌ Error al insertar distribuidor: " + distribuidor.getNombre(), e);
        }
        return false;
    }

    public boolean actualizarDistribuidor(Distribuidor distribuidor) {
        if (distribuidor == null || distribuidor.getIdDistribuidor() <= 0) {
            LOGGER.warning("⚠️ Datos de distribuidor inválidos para actualización");
            return false;
        }
        try (Connection conn = Conexion.getConnection()) {
            if (conn == null) {
                LOGGER.severe("❌ No se pudo establecer conexión a la base de datos");
                return false;
            }
            distribuidor.trimAllFields();
            try (PreparedStatement pstmt = conn.prepareStatement(SQL_UPDATE)) {
                pstmt.setString(1, distribuidor.getNombre());
                pstmt.setString(2, distribuidor.getDireccion());
                pstmt.setString(3, distribuidor.getTelefono());
                pstmt.setInt(4, distribuidor.getIdDistribuidor());

                int filasAfectadas = pstmt.executeUpdate();
                return filasAfectadas > 0;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "❌ Error al actualizar distribuidor con ID: " + distribuidor.getIdDistribuidor(), e);
        }
        return false;
    }

    public boolean eliminarDistribuidor(int id) {
        if (id <= 0) {
            LOGGER.warning("⚠️ ID inválido para eliminar: " + id);
            return false;
        }
        try (Connection conn = Conexion.getConnection()) {
            if (conn == null) {
                LOGGER.severe("❌ No se pudo establecer conexión a la base de datos");
                return false;
            }
            try (PreparedStatement pstmt = conn.prepareStatement(SQL_DELETE)) {
                pstmt.setInt(1, id);
                int filasAfectadas = pstmt.executeUpdate();
                return filasAfectadas > 0;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "❌ Error al eliminar distribuidor con ID: " + id, e);
        }
        return false;
    }

    public List<Distribuidor> buscarDistribuidoresAvanzado(Integer id, String nombre, String direccion, String telefono) {
        List<Distribuidor> distribuidores = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT id_distribuidor, nombre, direccion, telefono FROM distribuidor WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (id != null) {
            sql.append(" AND id_distribuidor = ?");
            params.add(id);
        }
        if (nombre != null && !nombre.trim().isEmpty()) {
            sql.append(" AND LOWER(nombre) LIKE LOWER(?)");
            params.add("%" + nombre.trim() + "%");
        }
        if (direccion != null && !direccion.trim().isEmpty()) {
            sql.append(" AND LOWER(direccion) LIKE LOWER(?)");
            params.add("%" + direccion.trim() + "%");
        }
        if (telefono != null && !telefono.trim().isEmpty()) {
            sql.append(" AND telefono LIKE ?");
            params.add("%" + telefono.trim() + "%");
        }
        sql.append(" ORDER BY id_distribuidor");

        try (Connection conn = Conexion.getConnection()) {
            if (conn == null) {
                LOGGER.severe("❌ No se pudo establecer conexión a la base de datos");
                return distribuidores;
            }
            try (PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    pstmt.setObject(i + 1, params.get(i));
                }
                try (ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        Distribuidor distribuidor = mapearResultSet(rs);
                        if (distribuidor != null) {
                            distribuidores.add(distribuidor);
                        }
                    }
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "❌ Error al buscar distribuidores con filtros", e);
        }
        return distribuidores;
    }

    private Distribuidor mapearResultSet(ResultSet rs) {
        try {
            return new Distribuidor(
                rs.getInt("id_distribuidor"),
                rs.getString("nombre"),
                rs.getString("direccion"),
                rs.getString("telefono")
            );
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "❌ Error al mapear ResultSet a Distribuidor", e);
            return null;
        }
    }
}
