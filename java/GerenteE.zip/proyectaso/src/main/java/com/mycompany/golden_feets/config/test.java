
package com.mycompany.golden_feets.config;


public class test {

    public static void main(String[] args) {
        
    //  conexion.getConnection();
        
        
    }
    
}
