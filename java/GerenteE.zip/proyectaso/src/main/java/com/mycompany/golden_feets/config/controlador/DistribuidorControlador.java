package com.mycompany.golden_feets.config.controlador;

import com.mycompany.golden_feets.config.modelo.Distribuidor;
import com.mycompany.golden_feets.config.modelo.dao.DistribuidorDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "DistribuidorControlador", urlPatterns = {"/DistribuidorControlador"})
public class DistribuidorControlador extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(DistribuidorControlador.class.getName());
    private final DistribuidorDAO disDAO = new DistribuidorDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) 
            throws ServletException, IOException {
        processRequest(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) 
            throws ServletException, IOException {
        processRequest(req, res);
    }

    protected void processRequest(HttpServletRequest req, HttpServletResponse res) 
            throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        res.setCharacterEncoding("UTF-8");
        
        String accion = req.getParameter("accion");
        if (accion == null || accion.trim().isEmpty()) {
            accion = "listar";
        }

        try {
            switch (accion.toLowerCase()) {
                case "listar":
                    listar(req, res);
                    break;
                case "nuevo":
                    mostrarFormulario(req, res, "nuevo", new Distribuidor());
                    break;
                case "guardar":
                    guardar(req, res);
                    break;
                case "editar":
                    editar(req, res);
                    break;
                case "ver":
                    ver(req, res);
                    break;
                case "eliminar":
                    eliminar(req, res);
                    break;
                case "buscar":
                    buscar(req, res);
                    break;
                default:
                    listar(req, res);
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error en controlador", e);
            req.setAttribute("error", "Error: " + e.getMessage());
            req.getRequestDispatcher("/vista/error.jsp").forward(req, res);
        }
    }

    private void listar(HttpServletRequest req, HttpServletResponse res) 
            throws ServletException, IOException {
        List<Distribuidor> distribuidores = disDAO.listarDistribuidores();
        req.setAttribute("distribuidores", distribuidores);
        req.getRequestDispatcher("/vista/listar.jsp").forward(req, res);
    }

    private void mostrarFormulario(HttpServletRequest req, HttpServletResponse res, 
                                 String accionForm, Distribuidor distribuidor) 
            throws ServletException, IOException {
        req.setAttribute("accionForm", accionForm);
        req.setAttribute("distribuidor", distribuidor);
        req.getRequestDispatcher("/vista/nuevo.jsp").forward(req, res);
    }

    private void guardar(HttpServletRequest req, HttpServletResponse res) 
            throws ServletException, IOException {
        
        Distribuidor d = new Distribuidor();
        try {
            d.setIdDistribuidor(Integer.parseInt(req.getParameter("idDistribuidor")));
        } catch (NumberFormatException e) {
            d.setIdDistribuidor(0);
        }
        d.setNombre(req.getParameter("nombre"));
        d.setDireccion(req.getParameter("direccion"));
        d.setTelefono(req.getParameter("telefono"));

        d.trimAllFields();
        boolean valid = true;
        StringBuilder errores = new StringBuilder();

        if (d.getNombre() == null || !d.getNombre().matches("[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,60}")) {
            valid = false;
            errores.append("El nombre debe tener entre 2 y 60 letras y espacios.<br>");
        }
        if (d.getDireccion() == null || d.getDireccion().length() < 5 || d.getDireccion().length() > 120) {
            valid = false;
            errores.append("La dirección debe tener entre 5 y 120 caracteres.<br>");
        }
        if (d.getTelefono() == null || !d.getTelefono().matches("\\d{7,10}")) {
            valid = false;
            errores.append("El teléfono debe tener entre 7 y 10 dígitos numéricos.<br>");
        }

        if (!valid) {
            req.setAttribute("error", errores.toString());
            mostrarFormulario(req, res, d.getIdDistribuidor() > 0 ? "editar" : "nuevo", d);
            return;
        }

        boolean resultado;
        String mensaje;
        
        if (d.getIdDistribuidor() > 0) {
            resultado = disDAO.actualizarDistribuidor(d);
            mensaje = resultado ? "Distribuidor actualizado correctamente" : "No se pudo actualizar el distribuidor";
        } else {
            resultado = disDAO.insertarDistribuidor(d);
            mensaje = resultado ? "Distribuidor creado correctamente" : "No se pudo crear el distribuidor";
        }

        if (resultado) {
            req.setAttribute("success", mensaje);
            listar(req, res);
        } else {
            req.setAttribute("error", mensaje);
            mostrarFormulario(req, res, d.getIdDistribuidor() > 0 ? "editar" : "nuevo", d);
        }
    }

    private void editar(HttpServletRequest req, HttpServletResponse res) 
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(req.getParameter("id"));
            Distribuidor d = disDAO.buscarPorId(id);
            if (d != null) {
                mostrarFormulario(req, res, "editar", d);
            } else {
                req.setAttribute("error", "Distribuidor no encontrado");
                listar(req, res);
            }
        } catch (NumberFormatException e) {
            req.setAttribute("error", "ID inválido");
            listar(req, res);
        }
    }

    private void ver(HttpServletRequest req, HttpServletResponse res) 
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(req.getParameter("id"));
            Distribuidor d = disDAO.buscarPorId(id);
            if (d != null) {
                req.setAttribute("distribuidor", d);
                req.getRequestDispatcher("/vista/ver.jsp").forward(req, res);
            } else {
                req.setAttribute("error", "Distribuidor no encontrado");
                listar(req, res);
            }
        } catch (NumberFormatException e) {
            req.setAttribute("error", "ID inválido");
            listar(req, res);
        }
    }

    private void eliminar(HttpServletRequest req, HttpServletResponse res) 
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(req.getParameter("id"));
            if (disDAO.eliminarDistribuidor(id)) {
                req.setAttribute("success", "Distribuidor eliminado correctamente");
            } else {
                req.setAttribute("error", "No se pudo eliminar el distribuidor");
            }
            listar(req, res);
        } catch (NumberFormatException e) {
            req.setAttribute("error", "ID inválido");
            listar(req, res);
        }
    }

    private void buscar(HttpServletRequest req, HttpServletResponse res) 
            throws ServletException, IOException {
        String idStr = req.getParameter("idDistribuidor");
        String nombre = req.getParameter("nombre");
        String direccion = req.getParameter("direccion");
        String telefono = req.getParameter("telefono");

        Integer id = null;
        try {
            if (idStr != null && !idStr.trim().isEmpty()) {
                id = Integer.parseInt(idStr);
            }
        } catch (NumberFormatException e) {
            // Ignorar filtro de ID si inválido
        }

        List<Distribuidor> distribuidores = disDAO.buscarDistribuidoresAvanzado(id, nombre, direccion, telefono);
        req.setAttribute("distribuidores", distribuidores);
        req.getRequestDispatcher("/vista/listar.jsp").forward(req, res);
    }
}
